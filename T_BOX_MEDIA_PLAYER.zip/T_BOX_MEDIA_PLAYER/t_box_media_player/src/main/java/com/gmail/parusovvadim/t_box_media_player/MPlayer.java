package com.gmail.parusovvadim.t_box_media_player;

import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.BitmapFactory;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;

import com.gmail.parusovvadim.encoder_uart.CMD_DATA;
import com.gmail.parusovvadim.encoder_uart.EncoderFolders;
import com.gmail.parusovvadim.encoder_uart.EncoderListTracks;
import com.gmail.parusovvadim.encoder_uart.EncoderMainHeader;
import com.gmail.parusovvadim.encoder_uart.TranslitAUDI;
import com.gmail.parusovvadim.media_directory.MusicFiles;
import com.gmail.parusovvadim.media_directory.NodeDirectory;
import com.gmail.parusovvadim.media_directory.TrackInfo;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.Random;
import java.util.Vector;

// TODO пренести в контрол
class UARTService
{
    static final int CMD_SEND_DATA = 0xAA;
}

public class MPlayer extends Service implements OnCompletionListener, MediaPlayer.OnErrorListener
{
    private static final String EXTRA_CMD = "com.gmail.parusovvadim.t_box_media_player.CMD";
    private static final String EXTRA_FOLDER = "com.gmail.parusovvadim.t_box_media_player.folder";
    private static final String EXTRA_TRACK = "com.gmail.parusovvadim.t_box_media_player.track";

    private static final int CMD_ERROR = 0x00;
    private static final int CMD_SELECT_TRACK = 0x05;
    private static final int CMD_PLAY = 0x06;
    private static final int CMD_PAUSE = 0x07;
    private static final int CMD_PREVIOUS = 0x08;
    private static final int CMD_NEXT = 0x09;
    private static final int CMD_CHANGE_ROOT = 0x0A;
    private static final int CMD_PLAY_PAUSE = 0x0B;
    private static final int CMD_SYNCHRONIZATION = 0x20;

    private static final int MAX_SIZE_DATA = 2816 - 10;

    private class InfoTrack
    {
        int folder;
        int track;
    }

    // метаданных трека
    final private MediaMetadataCompat.Builder metadataBuilder = new MediaMetadataCompat.Builder();
    // состояния плеера и обрабатываемые действия
    final private PlaybackStateCompat.Builder m_playbackStateCompat = new PlaybackStateCompat.Builder().setActions(PlaybackStateCompat.ACTION_PLAY | PlaybackStateCompat.ACTION_STOP | PlaybackStateCompat.ACTION_PAUSE | PlaybackStateCompat.ACTION_PLAY_PAUSE | PlaybackStateCompat.ACTION_SKIP_TO_NEXT | PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS | PlaybackStateCompat.ACTION_SEEK_TO | PlaybackStateCompat.ACTION_SKIP_TO_QUEUE_ITEM | PlaybackStateCompat.ACTION_REWIND | PlaybackStateCompat.ACTION_FAST_FORWARD | PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID);
    // Медиасессия плеера
    private MediaSessionCompat m_mediaSessionCompat = null;
    // Шторка управления плеером
    private NotificationSoundControl m_notificationSoundControl = null;

    // Плеер для воспроизведения
    private MediaPlayer m_mediaPlayer = null;

    // Действие при смене источника звука
    private final NoisyAudioStreamReceiver m_noisyAudioStreamReceiver = new NoisyAudioStreamReceiver();

    // аудио фокус
    private AudioManager m_audioManager = null;
    private final AFListener m_afLiListener = new AFListener();
    private AudioFocusRequest m_audioFocusRequest = null;

    // Текущий выбранный трек
    private NodeDirectory m_currentTrack = null; // Установить на первую песню
    // дериктория для воспроизведения
    private MusicFiles m_musicFiles;
    private boolean m_isPause = false;

    private boolean m_shuffle = false;
    private Random m_rand = new Random();

    @Override
    public void onCreate()
    {
        super.onCreate();
        createMediaSession();
        createAudioManager();
        createPlayer();
        changeRoot();
        m_notificationSoundControl = new NotificationSoundControl(this, m_mediaSessionCompat);
        selectTrack(1, 0);
    }

    public boolean isShuffle()
    {
        return m_shuffle;
    }

    private void createAudioManager()
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    // Собираемся воспроизводить звуковой контент
                    // (а не звук уведомления или звонок будильника)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    // ...и именно музыку (а не трек фильма или речь)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            m_audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setOnAudioFocusChangeListener(m_afLiListener)
                    // Если получить фокус не удалось, ничего не делаем
                    // Если true - нам выдадут фокус как только это будет возможно
                    // (например, закончится телефонный разговор)
                    .setAcceptsDelayedFocusGain(false)
                    // Вместо уменьшения громкости собираемся вставать на паузу
                    .setWillPauseWhenDucked(true).setAudioAttributes(audioAttributes).build();
        }
        m_audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
    }

    @Override
    public void onDestroy()
    {
        super.onDestroy();
        if(m_mediaPlayer != null) m_mediaPlayer.release();
        m_isPause = false;
        stopPlayback();
        m_mediaSessionCompat.release();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        MediaButtonReceiver.handleIntent(m_mediaSessionCompat, intent);
        parserCMD(intent);
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCompletion(MediaPlayer mp)
    {
        m_mediaSessionCallback.onSkipToNext();
    }

    private void createMediaSession()
    {

        Context appContext = getApplicationContext();

        m_mediaSessionCompat = new MediaSessionCompat(this, appContext.getPackageName());
        m_mediaSessionCompat.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS | MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
        m_mediaSessionCompat.setCallback(m_mediaSessionCallback);

        Intent activityIntent = new Intent(appContext, MainActivity.class);
        // Запуск активити по умолчанию;
        m_mediaSessionCompat.setSessionActivity(PendingIntent.getActivity(appContext, 0, activityIntent, 0));
        // при(setActive(false)), его пробудят бродкастом
        Intent mediaButtonIntent = new Intent(Intent.ACTION_MEDIA_BUTTON, null, appContext, MediaButtonReceiver.class);
        m_mediaSessionCompat.setMediaButtonReceiver(PendingIntent.getBroadcast(appContext, 0, mediaButtonIntent, 0));
    }

    private void abandonAudioFocus()
    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            m_audioManager.abandonAudioFocusRequest(m_audioFocusRequest);
        else m_audioManager.abandonAudioFocus(m_afLiListener);
    }

    private void play()
    {
        startPlayback();
        m_isPause = false;
        m_mediaPlayer.start();
    }

    private void pause()
    {
        stopPlayback();
        m_mediaPlayer.pause();
    }

    private void stop()
    {
        m_isPause = false;
        stopPlayback();
        m_mediaPlayer.stop();
    }

    private void playNext()
    {
        if(m_currentTrack != null)
        {
            if(isShuffle())
            {
                int newSong = m_currentTrack.getNumber();
                int sizeListTrack = m_musicFiles.getTracks(m_currentTrack.getParentNumber()).size();

                if(sizeListTrack > 1) while(newSong == m_currentTrack.getNumber())
                {
                    newSong = m_rand.nextInt(sizeListTrack);
                }
                selectTrack(m_currentTrack.getParentNumber(), newSong);

            } else
            {
                int indexTrack = m_currentTrack.getNumber() + 1;
                int countTrack = m_musicFiles.getTracks(m_currentTrack.getParentNumber()).size();
                if(indexTrack < countTrack)
                {
                    selectTrack(m_currentTrack.getParentNumber(), indexTrack);
                } else
                {
                    nextFolder();
                }
            }
        }
    }

    ///TODO сделать тест на переходы по папкам
    private void nextFolder()
    {
        int parentNumber = m_currentTrack.getParentNumber() + 1;
        while(parentNumber <= (m_musicFiles.getFolders().size()))
        {
            NodeDirectory trackNode = m_musicFiles.getTrack(parentNumber, 0);
            if(trackNode != null)
            {
                // запускаем трек
                m_currentTrack = trackNode;
                startPlayer();
                break;
            }
            parentNumber++;
        }
    }

    private void playPrevious()
    {
        if(m_currentTrack != null)
        {
            int indexTrack = m_currentTrack.getNumber() - 1;
            selectTrack(m_currentTrack.getParentNumber(), indexTrack);
        }
    }

    private void selectTrack(int folder, int track)
    {
        NodeDirectory trackNode = m_musicFiles.getTrack(folder, track);
        if(trackNode != null)
        {
            // запускаем трек
            m_currentTrack = trackNode;
            startPlayer();
        }
    }

    private void startPlayer()
    {
        // Устанавливаем дорожу
        setupPlayer(m_currentTrack.getPathDir());
    }

    private boolean isPlay()
    {
        return m_mediaPlayer.isPlaying();
    }

    // получение в времени в мсек
    private int getCurrentPosition()
    {
        return m_mediaPlayer.getCurrentPosition();
    }

    // получение в времени в мсек
    private void setCurrentPosition(long pos)
    {
        if(m_mediaPlayer != null) m_mediaPlayer.seekTo((int) pos);
    }

    // Установка громкости плеера
    private void setVolume(float leftVolume, float rightVolume)
    {
        m_mediaPlayer.setVolume(leftVolume, rightVolume);
    }

    // создает плеер
    private void createPlayer()
    {
        m_mediaPlayer = new MediaPlayer();
        // Устанавливаем наблюдателя по оканчанию дорожки
        m_mediaPlayer.setOnCompletionListener(this);
    }

    // Устанавливаем дорожку для запуска плеера
    private void setupPlayer(String audio)
    {
        try
        {
            m_mediaPlayer.reset();
            m_mediaPlayer.setDataSource(audio);
            m_mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            m_mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            m_mediaPlayer.prepare();

        } catch(IOException e)
        {
            e.printStackTrace();
        }
    }

    private void parserCMD(Intent intent)
    {
        if(intent == null) return;

        int cmd = getCMD(intent);

        switch(cmd)
        {
            case CMD_NEXT:
                m_mediaSessionCallback.onSkipToNext();
                break;
            case CMD_PREVIOUS:
                m_mediaSessionCallback.onSkipToPrevious();
                break;
            case CMD_PAUSE:
                m_mediaSessionCallback.onPause();
                break;
            case CMD_PLAY:
                m_mediaSessionCallback.onPlay();
                break;

            case CMD_PLAY_PAUSE:
                if(isPlay()) m_mediaSessionCallback.onPause();
                else m_mediaSessionCallback.onPlay();

                break;
            case CMD_CHANGE_ROOT:
                changeRoot();
                break;

            case CMD_SYNCHRONIZATION:
                startUART();
                break;
            case CMD_SELECT_TRACK:
            {
                int folder = intent.getIntExtra("folder", -1);
                int track = intent.getIntExtra("track", 0) - 1;
                selectTrack(folder, track);
                m_mediaSessionCallback.onPlay();
                break;
            }
            default:
                break;
        }
    }

    private void changeRoot()
    {
        m_mediaSessionCallback.onStop();
        m_musicFiles = MusicFiles.getInstance();
        selectTrack(1, 0);
    }

    @Override
    public boolean onError(MediaPlayer mediaPlayer, int i, int i1)
    {
        return false;
    }

    // Аудио фокус
    class AFListener implements AudioManager.OnAudioFocusChangeListener
    {
        @Override
        public void onAudioFocusChange(int i)
        {
            switch(i)
            {
                case AudioManager.AUDIOFOCUS_LOSS:
                    m_isPause = true;
                    m_mediaSessionCallback.onPause();
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    m_isPause = true;
                    m_mediaSessionCallback.onPause();
                    break;
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                    setVolume(0.5f, 0.5f);
                    break;
                case AudioManager.AUDIOFOCUS_GAIN:
                    if(!isPlay()) m_mediaSessionCallback.onPlay();
                    setVolume(1.0f, 1.0f);
                    break;
            }
        }
    }

    // Действия при смене источника звука
    private class NoisyAudioStreamReceiver extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(intent.getAction()))
                m_mediaSessionCallback.onPause();
        }
    }

    private void startPlayback()
    {
        if(!m_isPause) // выполняем инициализацию фокуса если только мы не на паузе
        {
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                m_audioManager.requestAudioFocus(m_audioFocusRequest);
            else
                m_audioManager.requestAudioFocus(m_afLiListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
        try
        {
            registerReceiver(m_noisyAudioStreamReceiver, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        } catch(IllegalArgumentException ignored)
        {
        }
    }

    private void stopPlayback()
    {
        if(!m_isPause) abandonAudioFocus(); // сбрасываем только по стопу
        try
        {
            unregisterReceiver(m_noisyAudioStreamReceiver);
        } catch(IllegalArgumentException e)
        {
            e.fillInStackTrace();
        }
    }

    // Колбэки для обработки медиасесси
    private final MediaSessionCompat.Callback m_mediaSessionCallback = new MediaSessionCompat.Callback()
    {
        @Override
        public void onPlay()
        {
            if(m_currentTrack == null) return;
            setMetaData();
            play();
            startMediaSession();
        }

        @Override
        public void onPause()
        {
            if(m_currentTrack == null) return;
            if(!isPlay()) return;
            // Останавливаем воспроизведение
            pause();
            // Сообщаем новое состояние
            m_mediaSessionCompat.setPlaybackState(m_playbackStateCompat.setState(PlaybackStateCompat.STATE_PAUSED, getCurrentPosition(), 1).build());
            m_notificationSoundControl.refreshNotificationAndForegroundStatus(PlaybackStateCompat.STATE_PAUSED);
        }

        @Override
        public void onSkipToQueueItem(long id)
        {
            if(m_currentTrack == null) return;
            selectTrack(m_currentTrack.getParentNumber(), (int) id);
        }

        @Override
        public void onStop()
        {
            if(m_currentTrack == null) return;
            // Останавливаем воспроизведение
            stop();
            // Все, больше мы не "главный" плеер, уходим со сцены
            m_mediaSessionCompat.setActive(false);
            // Сообщаем новое состояние
            m_mediaSessionCompat.setPlaybackState(m_playbackStateCompat.setState(PlaybackStateCompat.STATE_STOPPED, PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN, 1).build());
            m_notificationSoundControl.refreshNotificationAndForegroundStatus(PlaybackStateCompat.STATE_STOPPED);

        }

        @Override
        public void onSetShuffleMode(int shuffleMode)
        {
            switch(shuffleMode)
            {
                case PlaybackStateCompat.SHUFFLE_MODE_NONE:
                    m_shuffle = false;
                    break;
                case PlaybackStateCompat.SHUFFLE_MODE_ALL:
                case PlaybackStateCompat.SHUFFLE_MODE_GROUP:
                    m_shuffle = true;

                    break;
                case PlaybackStateCompat.SHUFFLE_MODE_INVALID:
                    break;
            }
        }

        @Override
        public void onCustomAction(String action, Bundle extras)
        {
            if(action.equals("shuffleMode"))
            {
                int shuffle = extras.getInt("isShuffle");
                m_mediaSessionCompat.setShuffleMode(shuffle);
                this.onSetShuffleMode(shuffle);
                return;
            }
            if(action.equals("synchronization"))
            {
                startUART();
            }
        }

        @Override
        public void onSeekTo(long pos)
        {
            if(m_currentTrack == null) return;
            setCurrentPosition(pos);
        }

        @Override
        public void onSkipToNext()
        {
            if(m_currentTrack == null) return;
            playNext();
            onPlay();
        }

        @Override
        public void onSkipToPrevious()
        {
            if(m_currentTrack == null) return;
            playPrevious();
            onPlay();
        }

        @Override
        public void onPlayFromMediaId(String mediaId, Bundle extras)
        {
            String[] ids = mediaId.split(";");
            if(ids.length == 2)
            {
                int folder = Integer.parseInt(ids[0]);
                int track = Integer.parseInt(ids[1]);
                selectTrack(folder, track);
                m_mediaSessionCallback.onPlay();
            }
        }

        @Override
        public void onFastForward()
        {
            if(m_currentTrack == null) return;
            int pos = getCurrentPosition() + 5000;
            setCurrentPosition(pos);
            m_mediaSessionCompat.setPlaybackState(m_playbackStateCompat.setState(PlaybackStateCompat.STATE_PLAYING, getCurrentPosition(), 1).build());
        }

        @Override
        public void onRewind()
        {
            if(m_currentTrack == null) return;
            int pos = getCurrentPosition() - 5000;
            if(pos < 0) pos = 0;

            setCurrentPosition(pos);
            m_mediaSessionCompat.setPlaybackState(m_playbackStateCompat.setState(PlaybackStateCompat.STATE_PLAYING, getCurrentPosition(), 1).build());
        }

        // Делаем медиа сессию активной
        void startMediaSession()
        {
            // Указываем, что наше приложение теперь активный плеер и кнопки
            // на окне блокировки должны управлять именно нами
            m_mediaSessionCompat.setActive(true);
            m_mediaSessionCompat.setPlaybackState(m_playbackStateCompat.setState(PlaybackStateCompat.STATE_PLAYING, getCurrentPosition(), 1).build());
            m_notificationSoundControl.refreshNotificationAndForegroundStatus(PlaybackStateCompat.STATE_PLAYING);
        }

        // Установка данных о треке
        private void setMetaData()
        {
            if(m_currentTrack == null) return;

            try
            {
                TrackInfo trackInfo = (TrackInfo) m_currentTrack;
                String artist = trackInfo.getArtist();
                String title = trackInfo.getTitle();
                String album = trackInfo.getAlbum();
                long durationMs = trackInfo.getDuration();
                byte[] art = trackInfo.getImage();

                // Заполняем данные о треке
                if(art != null)
                    metadataBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, BitmapFactory.decodeByteArray(art, 0, art.length));
                else
                    metadataBuilder.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, BitmapFactory.decodeResource(getResources(), R.drawable.image_t_box));

                metadataBuilder.putString(MediaMetadataCompat.METADATA_KEY_TITLE, title).putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album).putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist).putString(MediaMetadataCompat.METADATA_KEY_MEDIA_ID, m_currentTrack.getParentNumber() + ";" + m_currentTrack.getNumber()).putLong(MediaMetadataCompat.METADATA_KEY_DURATION, durationMs);

                MediaMetadataCompat metadata = metadataBuilder.build();
                m_mediaSessionCompat.setMetadata(metadata);

            } catch(RuntimeException e)
            {
                e.fillInStackTrace();
                onSkipToPrevious();
            }

        }

    };

    // Для доступа извне к MediaSession требуется токен
    @Override
    public IBinder onBind(Intent intent)
    {
        return new MPlayerBinder();
    }

    public class MPlayerBinder extends Binder
    {
        public MediaSessionCompat.Token getMediaSessionToken()
        {
            return m_mediaSessionCompat.getSessionToken();
        }

        public Boolean getShuffle()
        {
            return m_shuffle;
        }

    }

    ////TODO перенести все в control
    // Синхронизация с АУДИ
    private void startUART()
    {
        sendInfoFoldersToComPort();
        sendInfoTracksToComPort();
    }

    private void sendInfoTracksToComPort()
    {
        Vector<NodeDirectory> folders = m_musicFiles.getFolders();
        EncoderListTracks encoderListTracks = new EncoderListTracks();

        for(NodeDirectory folder : folders)
        {
            int lastNumberBlock = 0;
            int startNewBlock = 0;
            Vector<Integer> endBlocks = new Vector<>();
            encoderListTracks.addHeader(folder.getNumber());

            Vector<Byte> headerDatas = (Vector<Byte>) encoderListTracks.getVectorByte().clone();
            Vector<NodeDirectory> tracks = m_musicFiles.getTracks(folder.getNumber());
            for(NodeDirectory track : tracks)
            {
                encoderListTracks.addTrackNumber(track.getNumber() + 1);
                encoderListTracks.addName(getTranslate(track.getName()));
                if((encoderListTracks.size() - startNewBlock) > MAX_SIZE_DATA)
                {
                    endBlocks.add(lastNumberBlock);
                    startNewBlock = lastNumberBlock;
                }
                lastNumberBlock = encoderListTracks.size();
            }

            encoderListTracks.addEnd();
            endBlocks.add(encoderListTracks.size());


            Vector<Vector<Byte>> dataList = GetListData(encoderListTracks.getVectorByte(), endBlocks, headerDatas);

            for(int i = 0; i < dataList.size(); i++)
            {

                dataList.get(i).insertElementAt((byte) i, 0);
                dataList.get(i).insertElementAt((byte) dataList.size(), 0);

                // Добавляем заголовок
                EncoderMainHeader headerData = new EncoderMainHeader(dataList.get(i));
                headerData.addMainHeader((byte) CMD_DATA.LIST_TRACK);

                Intent intent = getIntentServiceUART();
                intent.putExtra(getString(R.string.CMD), UARTService.CMD_SEND_DATA);
                intent.putExtra("Data", headerData.getDataByte());
                startService(intent);
            }
        }
    }

    private void sendInfoFoldersToComPort()
    {
        Vector<NodeDirectory> folders = m_musicFiles.getFolders();
        int lastNumberBlock = 0;
        int startNewBlock = 0;
        Vector<Integer> endBlocks = new Vector<>();

        EncoderFolders encoderFolders = new EncoderFolders();
        encoderFolders.addHeader();
        Vector<Byte> headerDatas = (Vector<Byte>) encoderFolders.getVectorByte().clone();

        for(NodeDirectory folder : folders)
        {
            encoderFolders.addName(getTranslate(folder.getName()));
            encoderFolders.addNumber(folder.getNumber());
            encoderFolders.addNumberTracks(folder.getNumberTracks());
            encoderFolders.addParentNumber(folder.getParentNumber());

            if((encoderFolders.size() - startNewBlock) > MAX_SIZE_DATA)
            {
                endBlocks.add(lastNumberBlock);
                startNewBlock = lastNumberBlock;
            }
            lastNumberBlock = encoderFolders.size();
        }

        encoderFolders.addEnd();

        endBlocks.add(encoderFolders.size());


        Vector<Vector<Byte>> dataList = GetListData(encoderFolders.getVectorByte(), endBlocks, headerDatas);

        for(int i = 0; i < dataList.size(); i++)
        {

            dataList.get(i).insertElementAt((byte) i, 0);
            dataList.get(i).insertElementAt((byte) dataList.size(), 0);
            // Добавляем заголовок
            EncoderMainHeader headerData = new EncoderMainHeader(dataList.get(i));
            headerData.addMainHeader((byte) CMD_DATA.LIST_FOLDER);

            Intent intent = getIntentServiceUART();
            intent.putExtra(getString(R.string.CMD), UARTService.CMD_SEND_DATA);
            intent.putExtra(getString(R.string.CMD_data), headerData.getDataByte());
            startService(intent);
        }

    }

    private static Vector<Vector<Byte>> GetListData(Vector<Byte> data, Vector<Integer> endBlocks, Vector<Byte> dataHeader)
    {
        Vector<Vector<Byte>> list = new Vector<>();
        int startIndex = 0;

        int i = 0;
        for(Integer stopIndex : endBlocks)
        {
            list.add(new Vector<>(data.subList(startIndex, stopIndex)));
            startIndex = stopIndex;
            if(i != 0) list.lastElement().addAll(0, dataHeader);
            i++;
        }
        return list;
    }

    // Получение Intent для отправки в UART
    private Intent getIntentServiceUART()
    {
        Intent intent = new Intent();
        intent.setClassName("com.gmail.parusovvadim.t_box_control", "com.gmail.parusovvadim.t_box_control.UARTService");
        return intent;
    }

    @NotNull
    private String getTranslate(String msg)
    {
        return TranslitAUDI.translate(msg);
    }

    /*
    КОМАНДЫ УПРАВЛЕНИЯ ПЛЕЕРОМ
     */

    // Форммирование интента для выбора трека
    public static Intent newIntentSelectTrack(Context packageContext, int folder, int track)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_SELECT_TRACK);
        intent.putExtra(EXTRA_FOLDER, folder);
        intent.putExtra(EXTRA_TRACK, track);
        return intent;
    }

    // Форммирование интента плай
    public static Intent newIntentPlay(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_PLAY);
        return intent;
    }

    // Форммирование интента пауза
    public static Intent newIntentPause(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_PAUSE);
        return intent;
    }

    // Форммирование интента переключения на предыдущий
    public static Intent newIntentPrevious(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_PREVIOUS);
        return intent;
    }

    // Форммирование интента Следующего трека
    public static Intent newIntentNext(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_NEXT);
        return intent;
    }

    // Форммирование интента изменения корня пути данных
    public static Intent newIntentChangeRoot(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_CHANGE_ROOT);
        return intent;
    }

    // Форммирование интента Плай-Пауза
    public static Intent newIntentPlayPause(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_PLAY_PAUSE);
        return intent;
    }

    // Форммирование интента для синхронизации плеера
    public static Intent newIntentSynchronization(Context packageContext)
    {
        Intent intent = new Intent(packageContext, MPlayer.class);
        intent.putExtra(EXTRA_CMD, CMD_SYNCHRONIZATION);
        return intent;
    }

    // Получение команды
    private int getCMD(Intent intent)
    {
        return intent.getIntExtra(EXTRA_CMD, CMD_ERROR);
    }

    // Получение информации о выбранном треке
    private InfoTrack getSelectTrack(Intent intent)
    {
        InfoTrack infoTrack = new InfoTrack();
        infoTrack.folder = intent.getIntExtra(EXTRA_FOLDER, -1);
        infoTrack.track = intent.getIntExtra(EXTRA_TRACK, 0) - 1;
        return infoTrack;
    }
}